

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */
 
extern char BufferDAT[14];

void GPS_STATUS(void);
void GPS_LATITUDE(void);
void GPS_LONGITUDE(void);
void GPS_TIMEDATE(void);



