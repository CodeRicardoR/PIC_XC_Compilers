
/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

#define FCY 29491200UL
void ConfigADC(void);
unsigned short ReadADC(char Channel);