
/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

void Config_TIMER1(void);
void Enable_TIMER1(void);
void Disable_TIMER1(void);

